# Ferrari Landing Page Project

A Pen created on CodePen.

Original URL: [https://codepen.io/jerbogwapo/pen/VYwXgxj](https://codepen.io/jerbogwapo/pen/VYwXgxj).

